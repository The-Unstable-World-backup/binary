== advtrains_line_automation
This mod provides an extension to the interlocking system which allows to automatically operate trains on train lines.

This extension makes use of the table
advtrains.lines