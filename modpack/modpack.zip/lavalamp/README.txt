Lava Lamps (lavalamp) mod for Minetest


by thefamilygrog66

Description:
Coloured Lava Lamps, loosely based on Tonyka's wall torches from the 3dforniture/homedecor mod. There are 6 colours in all: red, orange, yellow, green, blue, violet.

After placing a lava lamp, the player can turn it off/on again by right-clicking on it.

Recipe:

+---------------+
| coloured wool |
+---------------+
| water bucket  |
+---------------+
|  black wool   |
+---------------+

Mod dependencies: wool, bucket

See also:
http://minetest.net/
