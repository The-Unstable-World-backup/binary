Minetest mod Carpet
===================
Version 1.0

Description
~~~~~~~~~~~
A mod for Minetest that adds carpets.
They are easily carftable by two wool blocks of the coulor you want.

Depends (Mods)
~~~~~~~~~~~~~~
Wool (included in most subgames like Minetest NeXt / Minetest Game)

License
~~~~~~~
Copyright (C) 2016 LNJ (@LNJplus)
    WTFPL (See http://www.wtfpl.net/txt/copying/)
