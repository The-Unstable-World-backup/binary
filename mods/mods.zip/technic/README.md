Technic
=======

License
-------

Copyright (C) 2012-2014 Maciej Kasatkin (RealBadAngel)

Technic chests code is licensed under the GNU LGPLv2+.

Texture licenses:

BlockMen modified by Zefram (CC BY-SA 3.0):
  * technic_chernobylite_block.png
  * technic_corium_flowing_animated.png
  * technic_corium_source_animated.png

celeron55 (Perttu Ahola) modified by Zefram (CC BY-SA 3.0):
  * technic_bucket_corium.png

sdzen (Elise Staudter) (CC BY-SA 3.0):
  * most of the older 16x16 textures

leftshift (CC BY-SA 3.0):
  * technic_river_water_can.png

RealBadAngel: (WTFPL)
  * Everything else.

CC BY-SA 3.0: <http://creativecommons.org/licenses/by-sa/3.0/>

Sound licenses:

veikk0 (Veikko Mäkelä) (CC BY-SA 4.0):
  * technic_hv_nuclear_reactor_siren_danger_loop.ogg
    * Derived from "Nuclear alarm.wav" by Freesound.org user rene___ from <https://freesound.org/people/rene___/sounds/56778/>. Originally licensed under CC0 1.0 <https://creativecommons.org/publicdomain/zero/1.0/>

CC BY-SA 4.0: <https://creativecommons.org/licenses/by-sa/4.0/>
