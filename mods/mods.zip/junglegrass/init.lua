minetest.register_alias("junglegrass:shortest", "air")
minetest.register_alias("junglegrass:short", "air")
minetest.register_alias("junglegrass:medium", "air")
