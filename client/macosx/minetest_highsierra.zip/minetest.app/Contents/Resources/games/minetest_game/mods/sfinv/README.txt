Minetest Game mod: sfinv
========================
See license.txt for license information.

Simple Fast Inventory.
A cleaner, simpler, solution to having an advanced inventory in Minetest.
See game_api.txt for this mod's API.
Available for use outside of MTG here:
https://forum.minetest.net/viewtopic.php?t=19765

Authors of source code
----------------------
rubenwardy (MIT)

Authors of media
----------------
paramat (CC BY-SA 3.0):
  sfinv_crafting_arrow.png - derived from a texture by BlockMen (CC BY-SA 3.0)
