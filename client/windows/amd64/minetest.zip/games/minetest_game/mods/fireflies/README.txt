Minetest Game mod: fireflies
============================
Adds fireflies to the world on mapgen, which can then be caught in a net and placed in
bottles to provide light.

Authors of source code
----------------------
Shara RedCat (MIT)

Authors of media (textures)
---------------------------
Shara RedCat (CC BY-SA 3.0):
  fireflies_firefly.png
  fireflies_firefly_animated.png
  fireflies_bugnet.png
  fireflies_bottle.png
  fireflies_bottle_animated.png

fireflies_bugnet.png is modified from a texture by tenplus1 (CC0)

fireflies_bottle.png and fireflies_bottle_animated.png are
modified from a texture by Vanessa Ezekowitz (CC BY-SA 3.0)