ctf_treasure = {}

function ctf_treasure.get_default_treasures()
	return {
		{ "default:ladder",          0.3, 5, {  1, 20 } },
		{ "default:torch",           0.3, 5, {  1, 20 } },
		{ "default:cobble",          0.4, 5, { 45, 99 } },
		{ "default:wood",            0.3, 5, { 30, 60 } },
		{ "doors:door_steel",        0.3, 5, {  1,  3 } },
		{ "ctf_traps:damage_cobble", 0.3, 4, { 10, 20 } },

		{ "default:pick_steel",   0.5, 5, { 1, 10 } },
		{ "default:sword_steel",  0.4, 5, { 1,  4 } },
		{ "default:shovel_stone", 0.6, 5, { 1, 10 } },
		{ "default:shovel_steel", 0.3, 5, { 1, 10 } },
		{ "default:axe_steel",    0.4, 5, { 1, 10 } },
		{ "default:axe_stone",    0.5, 5, { 1, 10 } },

		{ "shooter:shotgun",     0.04, 2, 1 },
		{ "shooter:grenade",     0.08, 2, 1 },
		{ "shooter:machine_gun", 0.02, 2, 1 },
		{ "shooter:crossbow",    0.5,  2, { 1,  5 } },
		{ "shooter:pistol",      0.4,  2, { 1,  5 } },
		{ "shooter:rifle",       0.1,  2, { 1,  2 } },
		{ "shooter:ammo",        0.3,  2, { 1, 10 } },
		{ "shooter:arrow_white", 0.5,  2, { 2, 18 } },

		{ "medkits:medkit",       0.8, 5, 2 },
		{ "ctf_bandages:bandage", 0.8, 2, { 2, 4 } }
	}
end
do
local default_treasures = ctf_treasure.get_default_treasures()
for _, v in ipairs{
 { "default:cobble",              0.6, 5, { 78, 99 } },
 { "default:wood",                0.6, 5, { 45, 99 } },
 { "default:sword_steel",         0.6, 5, { 1, 10 } },
 { "default:shovel_steel",        0.6, 5, { 1, 10 } },
 { "default:shovel_steel",        0.6, 5, { 1, 10 } },
 { "shooter:shotgun",             0.3, 2, 1 },
 { "shooter:grenade",             0.3, 2, 1 },
 { "shooter:machine_gun",         0.3, 2, 1 },
 { "vehicles:missile_2_item",     0.3, 2, 5 },
 { "vehicles:rc",                 0.3, 2, 1 },
 { "vehicles:apache_spawner",     0.2, 2, 1 },
 { "vehicles:plane_spawner",      0.2, 2, 1 },
 { "vehicles:backpack",           0.3, 2, 1 }
} do table.insert(default_treasures, v) end
function ctf_treasure.get_default_treasures() return default_treasures end
end
