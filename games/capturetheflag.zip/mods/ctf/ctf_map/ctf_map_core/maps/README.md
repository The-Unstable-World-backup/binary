# Maps for CTF

Feel free to create PRs for new maps. Checkout `ctf_map`'s README.md for more documentation.

## License
All individual maps are published under their own license, as given by the `license` field in `<map_name>.conf`
