[mod] 3d wielded items [wield3d]
================================

Mod Version: 0.3.0

Minetest Version: 0.4.12 or later

Decription: Visible 3d wielded items for Minetest

Depends: default

Makes hand wielded items visible to other players.

See wield3d.conf.example for config options (save as wield3d.conf)

