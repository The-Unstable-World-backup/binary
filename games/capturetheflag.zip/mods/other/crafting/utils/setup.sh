#!/bin/bash

ln -s ../../utils/pre-commit.sh .git/hooks/pre-commit
