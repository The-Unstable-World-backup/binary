# Email

![screenshot](https://cdn.pbrd.co/images/8fn5I3u.png)

Created by rubenwardy.

License: WTFPL.

## Usage

Send an email:

* /mail username message to send

View inbox:

* /inbox
* /inbox text

No formspec commands (good for IRC):

* /mail username message to send
* /inbox text
* /inbox clear
