minetest-dropondie
==================

Minecraft-like drop-all-items-on-die mod
