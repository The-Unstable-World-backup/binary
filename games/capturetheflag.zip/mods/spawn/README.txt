Minetest Game mod: spawn
========================
See license.txt for license information.

Authors of source code
----------------------
paramat (MIT)
